#include<bits/stdc++.h>
#include <list>
#include <vector>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
using namespace std;
class Graph {
 private:
 vector<vector<int> > adjMatrix;
 vector<string> city;
 int numVertices;
 public:
 Graph(); 
 vector<vector<int> > getadj();
 void printcity();
 void addVertices();
 void addEdge();
 void removeEdge();
 int minDistance(int dist[], bool sptSet[]);
 int dijkstra(vector<vector<int> > adjMatrix, int src, int dest,bool enr);
 void toString(); 
 void directway();
 void indirectway();
 void search();
 void anyway();
 int printSolution(int dist[],int dest);
};