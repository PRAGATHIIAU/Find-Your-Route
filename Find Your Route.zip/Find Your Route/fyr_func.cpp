#include <iostream>
#include<bits/stdc++.h>
#include <list>
#include <vector>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include "fyr.h"
using namespace std;
 Graph::Graph() //CONSTRUCTOR
{
 this->numVertices = 4 ;
 for(int i=0;i<4;i++)
 {
 vector<int> temp;
 if(i==0)
 {
 temp.push_back(0);
 temp.push_back(456);
 temp.push_back(789);
 temp.push_back(0);
 city.push_back("Madurai");
 adjMatrix.push_back(temp);
}
else if(i==1)
{
temp.push_back(456);
 temp.push_back(0);
 temp.push_back(0);
 temp.push_back(2547);
 city.push_back("Chennai");
 adjMatrix.push_back(temp);
}
else if(i==2)
{
temp.push_back(789);
 temp.push_back(0);
 temp.push_back(0);
 temp.push_back(856);
 city.push_back("Salem");
 adjMatrix.push_back(temp);
}
else if(i==3)
{
temp.push_back(0);
 temp.push_back(2547);
 temp.push_back(856);
 temp.push_back(0);
 city.push_back("Erode");
 adjMatrix.push_back(temp);
}
}
 
 }
 vector<vector<int> > Graph::getadj() //RETURNS ADJMATRIX
 {
 return adjMatrix;
 }
 
 void Graph::printcity() //PRINTS AVAILABLE CITIES
 {
 cout<<"\nThe available cities are:\n";
for(int i=0;i<city.size();i++)
 {
 cout<<i+1<<". "<<city[i]<<endl;
}
}
void Graph::addVertices() //ADD'S A NEW CITY
 {
 string s;
numVertices+=1;
 adjMatrix.resize(numVertices);
 for (int i = 0; i < numVertices; ++i)
 {
 adjMatrix[i].resize(numVertices);
 } 
 cout<<"Enter the city to be added: ";
 cin>>s;
 city.push_back(s);
 }
 
 void Graph::addEdge() //ADD'S A NEW EDGE BTW TWO CITIES
{
 int i,j;
 printcity();
cout<<"Enter city 1: ";
 cin>>i;
 cout<<"Enter city 2: ";
 cin>>j;
int d;
 cout<<"Enter the distance between two cities: ";
 cin>>d;
adjMatrix[i-1][j-1] = d;
 adjMatrix[j-1][i-1] = d;
 }
 void Graph::removeEdge() //REMOVES AN EDGE
{
 int i,j;
 printcity();
 cout<<"Enter city 1: ";
 cin>>i;
 cout<<"Enter city 2: ";
 cin>>j;
 adjMatrix[i-1][j-1] = 0;
 adjMatrix[j-1][i-1] = 0;
 }
 
 int Graph::minDistance(int dist[], bool sptSet[]) 
{
int min = INT_MAX, min_index;
for (int v = 0; v < numVertices; v++)
if (sptSet[v] == false && dist[v] <= min)
min = dist[v], min_index = v;
return min_index;
}
int Graph::printSolution(int dist[],int dest)
{
for (int i = 0; i < numVertices; i++)
 if(i==dest)
 return dist[i];
}
int Graph::dijkstra(vector<vector<int> > adjMatrix, int src,int dest,bool enr) //FINDS 
SHORTEST ROUTE
{
int V=numVertices;
int dist[V];
vector<string> visited; 
bool sptSet[V];
for (int i = 0; i < V; i++)
dist[i] = INT_MAX, sptSet[i] = false;
dist[src] = 0;
 visited.push_back(city[src]);
for (int count = 0; count < V - 1; count++) {
int u = minDistance(dist, sptSet);
sptSet[u] = true;
for (int v = 0; v < V; v++)
if (!sptSet[v] && adjMatrix[u][v] && dist[u] != INT_MAX
&& dist[u] + adjMatrix[u][v] < dist[v])
{
dist[v] = dist[u] + adjMatrix[u][v];
 visited.push_back(city[u]);
}
}
visited.push_back(city[dest]);
if(enr && dist[dest]!=0 && dist[dest]!=INT_MAX)
{
cout<<"\nThe Route is: ";
int k=0;
for(int i=0;i<visited.size();i++)
{
k=0;
for(int j=0;j<i;j++)
{
if(visited[i]==visited[j])
 k++;
}
if(k==0)
{
cout<<visited[i];
if(i<visited.size()-1)
cout<<"-->";
 }
}
cout<<endl;
 }
return printSolution(dist,dest);
}
 void Graph::toString() //PRINTS ADJACENCY MATRIX
{
cout<<"\n**********ADJACENCY MATRIX********\n";
for(int j=0;j<city.size();j++)
{
cout<<"\t\t"<<city[j];
}
cout<<endl;
 for (int i = 0; i < numVertices; i++) 
{
 cout << city[i] << " : \t";
 for (int j = 0; j < numVertices; j++)
 cout << adjMatrix[i][j] << " \t\t";
 cout << "\n";
 }
 cout<<"\n************************\n";
 }
 
 void Graph::directway() // FINDS THE DIRECT WAY
 {
 int i,j;
 printcity();
 cout<<"Enter your current location:";
 cin>>i;
 cout<<"Enter your destination location:";
 cin>>j;
 if(adjMatrix[i-1][j-1]==0)
 cout<<"Sorry there is no direct route for this place\n";
 else
 {
 
 cout<<"\nThere is a route with minimum distance of: "<<adjMatrix[i-1][j1]<<"KM"<<endl;
 }
}
void Graph::indirectway() //FINDS THE INDIRECT WAY VIA ANOTHER CITY
{
int d1,d2;
int i,j,k;
 printcity();
 cout<<"Enter your current location:";
 cin>>i;
 cout<<"Enter your destination location:";
 cin>>j;
 cout<<"Enter your intermediate location:";
 cin>>k;
d1=dijkstra(getadj(),i-1,k-1,TRUE);
d2=dijkstra(getadj(),k-1,j-1,TRUE);
if(d1+d2==INT_MAX || d1+d2==0)
 cout<<"\nSorry there is no route passing through "<<city[k-1]<<endl;
 else
 {
 cout<<"\nThere is a route with minimum distance of: "<<d1+d2<<"KM"<<endl;
 }
}
void Graph::search() //PRINTS INFO ABOUT THE REQUESTED CITY
{
string s;
printcity();
cout<<"Enter the city name to be searched: ";
cin>>s;
for(int i=0;i<city.size();i++)
{
if(s==city[i])
{
cout<<endl<<s<<" has a direct connection with the following 
cities:\n";
for(int j=0;j<numVertices;j++)
{
if(!(adjMatrix[i][j]==0 || adjMatrix[i][j]==INT_MAX))
 cout<<city[j]<<endl;
}
}
}
}
void Graph::anyway() //PRINTS MOST OPTIMAL OF DIRECT AND INDIRECT WAY
{
int i,j,d1;
 printcity();
 cout<<"Enter your current location:";
 cin>>i;
 cout<<"Enter your destination location:";
 cin>>j;
 d1=dijkstra(getadj(),i-1,j-1,TRUE);
if(d1==INT_MAX || d1==0)
 cout<<"\nSorry there is no route"<<endl;
 else
 {
 cout<<"\nThere is a route with minimum distance of: "<<d1<<"KM"<<endl;
 }
}