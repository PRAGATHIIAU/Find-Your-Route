#include <iostream>
#include<bits/stdc++.h>
#include <list>
#include <vector>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include "fyr.h"
using namespace std;
void Color(int color)
{
SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}
int main() {
Graph g;
int i;
int ch=0,ch1=0,ch2=0,op;
cout<<"\t";
for(i=0;i<=70;i++)
cout<<"*";
cout<<endl;
Color(4);
cout<<"\t\t\t\t";
cout<<"!!! WELCOME !!!!";
cout<<"\n\n\n";
cout<<"\t\t\t\t";
Color(12);
cout<<" PICK YOUR ROUTE\n\n\n";
Color(6);
cout<<"\t\t\t\t A One Stop for \n \t\t\t\t Your Fast Journey\n\n\n";
Color(7);
cout<<"\t";
for(i=0;i<=70;i++)
cout<<"*";
while(ch==0)
{
Color(10);
cout<<"\n\n\n\t\tEnter 1 if you are an admin. Enter 2 if you are an user. Enter 3 to 
exit.\n\t\t";
cin>>op;
switch(op)
{
ad:
case 1:
system("CLS");
int pwd;
int n;
Color(4);
cout<<"\n\nIf pressed wrongly,Enter 1 to go to user section 
else enter 2 to continue:";
cin>>n;
if (n==1)
{
goto user;
}
else if(n==2)
{
system("CLS");
cout<<"\t\t\tHey admin\n";
admin:
cout<<"\t\t\tEnter the password to 
proceed further:\n\t\t\t";
cin>>pwd;
if (pwd==123)
{
system("CLS");
while(ch1==0)
{
int ao;
Color(9);
cout<<"\n\t\t\t Welcome admin 
!! \n\t\t What operation do you wish to perform??\n";
cout<<"\t\t 1.Insert a new city 
\n\t\t 2.Insert an edge\n\t\t 3.Delete an edge \n\t\t 4.Display all cities \n\t\t 5.Search for a 
city \n\t\t 6.Print adjacency matrix \n\t\t 7.Exit\n\n\t\t";
cin>>ao;
switch(ao)
{
case 1:
g.addVertices();
break;
case 2:
g.addEdge();
break;
case 3:
g.removeEdge();
break;
case 4:
g.printcity();
break;
case 5:
g.search();
break;
case 6:
g.toString();
break;
case 7:
ch1=1;
break;
default:
cout<<"\n\t\t\t 
Please enter a choice between 1 and 5.";
}
}
}
else
{
cout<<"\t\t\tPlease enter the 
correct password.\n";
goto admin;
}
 }
 else
 {
 cout<<"\n\t\t Invalid option.";
 goto ad;
}
break;
user:
case 2:
system("CLS");
Color(7);
cout<<"\n\t";
for(i=0;i<=70;i++)
{
if ((i>=0 && i<10) || (i>=20 && i<30) || (i>=40 
&& i<50)|| (i>=60 && i<=70))
{
Color(1);
cout<<"*";
}
else
{
Color(2);
cout<<"*";
}
}
cout<<endl;
Color(6);
cout<<"\t\t\t\t";
cout<<"!!! WELCOME !!!!";
cout<<"\n\n\n";
cout<<"\t\t\t\t";
Color(12);
cout<<" PICK YOUR ROUTE\n\n\n";
Color(5);
cout<<"\t\t\t\t A One Stop for \n \t\t\t\t Your Fast 
Journey\n\n\n";
cout<<"\t";
for(i=0;i<=70;i++)
{
if ((i>=0 && i<10) || (i>=20 && i<30) || (i>=40 
&& i<50)|| (i>=60 && i<=70))
{
Color(1);
cout<<"*";
}
else
{
Color(2);
cout<<"*";
}
}
cout<<"\n\n\t\t\t";
Color(8);
cout<<"Hey user !!! Welcome to our service \"Pick your 
route\". \n\t\t ";
Color(7);
cout<<"Here we provide you with the information on 
the shortest route \n\t\t to take while you travel from a place to another.";
cout<"\n\n\t\t\t";
int m;
method:
Color(3);
while(ch2==0)
{
cout<<"\n\n\n\n\t\tWhich method do you want to 
calculate the distance??";
cout<<"\n\t\t 1. Direct by giving two places \n\t\t 2. 
Indirect via by giving three places \n\t\t 3.Any optimal route \n\t\t 4.Exit\n\n\n\t\t" ;
cin>>m;
switch (m)
{
case 1:
g.directway();
break;
case 2:
g.indirectway();
break;
case 3:
g.anyway();
break;
case 4:
ch2=1;
break;
default:
cout<<"\t\tPlease enter either 1, 2 or 3";
goto method;
break;
}
}
break;
case 3:
ch=1;
break;
default:
cout<<"\t\t\tWrong choice.Please enter 1,2 or 3";
break;
}
}
end:
system("CLS");
Color(6);
cout<<"\n\n\t\t THANK YOU FOR USING OUR SERVICE !!!!!! \n\n\t\t DO VISIT AGAIN 
!!!!!!";
Color(7);
return 1;
}
